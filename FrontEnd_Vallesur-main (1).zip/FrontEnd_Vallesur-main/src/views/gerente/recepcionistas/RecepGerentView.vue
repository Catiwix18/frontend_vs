<template>
  <div class="html">
    <div class="body-app">
      <div class="app-container">
        <SidebarComponent>
          <ListSidebarGerente />
        </SidebarComponent>

        <div class="app-content">
          <HeaderComponent>
            <template #title> Recepcionistas </template>
            <template #actions>
              <ActionsComponent />
            </template>
            <template #button-insert>
              <button
                class="app-content-headerButton"
                data-bs-toggle="modal"
                data-bs-target="#CreateRecep"
              >
                Registrar Recepcion
              </button>
              <!-- Modal -->
              <div
                class="modal fade"
                id="CreateRecep"
                data-bs-backdrop="static"
                data-bs-keyboard="false"
                tabindex="-1"
                aria-labelledby="staticBackdropLabel"
                aria-hidden="true"
              >
                <div class="modal-dialog modal-dialog-centered ">
                  <div class="modal-content " style="background: var(--app-content-secondary-color);">
                    <div class="modal-header">
                      <h1 class="modal-title fs-5 text-white" id="staticBackdropLabel">
                        Registrar Recepcion
                      </h1>
                      <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      ></button>
                    </div>
                    
                      <div class="modal-body">
                        <form
                          action="{{ route('gerente/recepcionistas-create') }}"
                          class="form form-updateUser"
                          method="POST"
                          onsubmit="validateRecepUser(event, 'create')"
                        >
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="number"
                              name="dni"
                              placeholder="Dni"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="text"
                              placeholder="Nombres"
                              name="nombres"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="text"
                              placeholder="Apellidos"
                              name="apellidos"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="hidden"
                              value="recepcionista"
                              name="permisos"
                            />
                            <label for="turno" class="form-label label-radio"
                              >Turno</label
                            >
                            <div class="form-radio">
                              <div class="radio-group">
                                <input
                                  class="form-input"
                                  type="radio"
                                  name="turno"
                                  value="mañana"
                                  checked
                                /><span>Mañana</span>
                              </div>
                              <div class="radio-group">
                                <input
                                  class="form-input"
                                  type="radio"
                                  name="turno"
                                  value="tarde"
                                /><span>Tarde</span>
                              </div>
                              <div class="radio-group">
                                <input
                                  class="form-input"
                                  type="radio"
                                  name="turno"
                                  value="noche"
                                /><span>Noche</span>
                              </div>
                              <div class="radio-group">
                                <input
                                  class="form-input"
                                  type="radio"
                                  name="turno"
                                  value="finesSemana"
                                /><span>Otros</span>
                              </div>
                            </div>
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="tel"
                              placeholder="Telefono"
                              name="telefono"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="email"
                              placeholder="Correo electrónico"
                              name="correo"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="password"
                              placeholder="Contraseña"
                              id="contrasena"
                              name="contrasena"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <input
                              class="form-input"
                              type="password"
                              placeholder="Confirmar contraseña"
                              id="contrasena-confirm"
                              name="contrasena-confirm"
                              required
                            />
                          </div>
                          <div class="form-group">
                            <button type="submit" class="raise btn-green">
                              Generar recepcionista
                            </button>
                            <a href="" class="raise btn-red button" data-bs-dismiss="modal">Cancelar</a>
                          </div>
                        </form>
                      </div>
                  </div>
                </div>
              </div>
              <!-- Fin Modal -->
            </template>
          </HeaderComponent>

          <!-- aqui contenido -->
          <div class="products-area-wrapper tableView">
            <div class="products-header">
              <div class="product-cell">
                Identificacion
                <button class="sort-button">
                  <i class="bi bi-arrow-down-up"></i>
                </button>
              </div>
              <div class="product-cell category">
                Nombres
                <button class="sort-button">
                  <i class="bi bi-arrow-down-up"></i>
                </button>
              </div>
              <div class="product-cell status-cell">
                Apellidos
                <button class="sort-button">
                  <i class="bi bi-arrow-down-up"></i>
                </button>
              </div>
              <div class="product-cell sales">
                Turno
                <button class="sort-button">
                  <i class="bi bi-arrow-down-up"></i>
                </button>
              </div>
              <div class="product-cell stock">
                Telefono
                <button class="sort-button">
                  <i class="bi bi-arrow-down-up"></i>
                </button>
              </div>
              <div class="product-cell price">Accion</div>
            </div>
          </div>
          <!-- Fin del contenido -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SidebarComponent from "@/components/SidebarComponent.vue";
import ListSidebarGerente from "@/views/gerente/recepcionistas/layout/ListSidebarView.vue";
import HeaderComponent from "@/components/HeaderComponent.vue";
import ActionsComponent from "@/components/ActionsComponent.vue";

export default {
  name: "RecepGerent",
  components: {
    SidebarComponent,
    ListSidebarGerente,
    HeaderComponent,
    ActionsComponent,
  },
};
</script>

<style>
@import url("@/css/app.css");
</style>