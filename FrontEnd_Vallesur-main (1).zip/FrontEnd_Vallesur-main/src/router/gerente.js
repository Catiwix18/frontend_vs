import HomeGerenteView from "@/views/gerente/HomeGerenteView.vue";
import RecepGerentView from "@/views/gerente/recepcionistas/RecepGerentView.vue";

const routes_gerente = [
  {
    path: "",
    name: "gerente-home",
    component: HomeGerenteView,
  },
  {
    path: "huespedes",
    name: "gerente-huespedes",
  },
  {
    path: "habitaciones",
    name: "gerente-habitaciones",
  },
  {
    path: "recepcionistas",
    name: "gerente-recepcionistas",
    component: RecepGerentView,
  },
  {
    path: "reportes",
    name: "gerente-reportes",
  },
  {
    path: "",
    name: "gerente-create-habitacion",
  },
];

export default routes_gerente;
